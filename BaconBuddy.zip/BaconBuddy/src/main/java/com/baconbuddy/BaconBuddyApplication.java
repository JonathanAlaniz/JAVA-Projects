package com.baconbuddy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaconBuddyApplication {

	public static void main(String[] args) {
		SpringApplication.run(BaconBuddyApplication.class, args);
	}

}
